const form = document.querySelector('#expenseForm');
const list = document.querySelector('#expenseList');
const emptyState = document.querySelector('#emptyState');
const filter = document.querySelector('#categoryFilter');
const template = document.querySelector('#expenseTemplate');
const search = document.querySelector('#searchExpenses');
const budgetDialog = document.querySelector('#budgetDialog');
const budgetInput = document.querySelector('#budgetAmount');
const currency = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' });
const icons = { Food: '🍲', Transport: '🚌', Shopping: '🛍️', Bills: '🧾', Health: '♥', Entertainment: '🎬', Other: '✦' };

function readStore(key, fallback) {
  try { const v = localStorage.getItem(key); return v === null ? fallback : v; } catch (e) { return fallback; }
}
function writeStore(key, value) {
  try { writeStore(key, value); } catch (e) { /* storage blocked */ }
}
function localToday() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
let expenses;
try { expenses = JSON.parse(readStore('pocketwise-expenses', '[]')); } catch (e) { expenses = []; }
if (!Array.isArray(expenses)) expenses = [];
expenses = expenses.filter(x => x && x.date && !isNaN(Number(x.amount))).map(x => ({ ...x, amount: Number(x.amount), category: x.category || 'Other' }));
let monthlyBudget = Number(readStore('pocketwise-budget', 0)) || 0;
let insightScope = readStore('pocketwise-scope', 'all') === 'month' ? 'month' : 'all';

const dateInput = document.querySelector('#expenseDate');
dateInput.value = localToday();
document.querySelector('#todayDate').textContent = new Intl.DateTimeFormat('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date());

function saveExpenses() {
  writeStore('pocketwise-expenses', JSON.stringify(expenses));
}

function monthExpenses() {
  const now = new Date();
  return expenses.filter(expense => {
    const date = new Date(`${expense.date}T00:00:00`);
    return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
  });
}

function formattedDate(value) {
  const date = new Date(`${value}T00:00:00`);
  return new Intl.DateTimeFormat('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }).format(date);
}

function render() {
  const selectedCategory = filter.value;
  const query = search.value.trim().toLowerCase();
  const visibleExpenses = expenses
    .filter(expense => (selectedCategory === 'All' || expense.category === selectedCategory) && expense.name.toLowerCase().includes(query))
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  list.innerHTML = '';
  visibleExpenses.forEach(expense => {
    const item = template.content.cloneNode(true);
    item.querySelector('.category-icon').textContent = icons[expense.category] || icons.Other;
    item.querySelector('.expense-title').textContent = expense.name;
    item.querySelector('.expense-category').textContent = expense.category;
    item.querySelector('.expense-date').textContent = formattedDate(expense.date);
    item.querySelector('.expense-date').dateTime = expense.date;
    item.querySelector('.expense-amount').textContent = currency.format(expense.amount);
    item.querySelector('.delete-button').addEventListener('click', () => {
      expenses = expenses.filter(item => item.id !== expense.id);
      saveExpenses();
      render();
    });
    list.append(item);
  });

  emptyState.hidden = visibleExpenses.length > 0;
  updateSummary();
  renderInsights();
}

function updateSummary() {
  const total = expenses.reduce((sum, expense) => sum + Number(expense.amount), 0);
  const thisMonth = monthExpenses();
  const monthTotal = thisMonth.reduce((sum, expense) => sum + Number(expense.amount), 0);
  document.querySelector('#totalSpent').textContent = currency.format(total);
  document.querySelector('#monthSpent').textContent = currency.format(monthTotal);
  document.querySelector('#expenseCount').textContent = `${expenses.length} expense${expenses.length === 1 ? '' : 's'} recorded`;
  document.querySelector('#monthNote').textContent = `${thisMonth.length} expense${thisMonth.length === 1 ? '' : 's'} this month`;
  const remaining = monthlyBudget - monthTotal;
  const budgetRemaining = document.querySelector('#budgetRemaining');
  const budgetNote = document.querySelector('#budgetNote');
  const progress = document.querySelector('#budgetProgress');
  if (monthlyBudget > 0) {
    budgetRemaining.textContent = remaining >= 0 ? `${currency.format(remaining)} left` : `${currency.format(Math.abs(remaining))} over`;
    budgetNote.textContent = `${currency.format(monthTotal)} of ${currency.format(monthlyBudget)} spent`;
    progress.style.width = `${Math.min((monthTotal / monthlyBudget) * 100, 100)}%`;
    progress.style.background = remaining >= 0 ? 'var(--green)' : '#d65a4d';
  } else {
    budgetRemaining.textContent = 'Not set';
    budgetNote.textContent = 'Choose a monthly spending limit';
    progress.style.width = '0';
  }
}

function renderInsights() {
  const container = document.querySelector('#categoryInsights');
  const source = insightScope === 'month' ? monthExpenses() : expenses;
  const categories = source.reduce((totals, expense) => {
    totals[expense.category] = (totals[expense.category] || 0) + Number(expense.amount);
    return totals;
  }, {});
  const entries = Object.entries(categories).sort(([, a], [, b]) => b - a).slice(0, 3);
  if (!entries.length) {
    const hasDataElsewhere = insightScope === 'month' && expenses.length > 0;
    container.innerHTML = hasDataElsewhere
      ? '<p class="insight-empty">No expenses recorded this month. Switch to <strong>All time</strong> to see your breakdown.</p>'
      : '<p class="insight-empty">Add expenses to see where your money goes.</p>';
    return;
  }
  const largest = entries[0][1];
  container.innerHTML = entries.map(([category, amount]) => `
    <div class="insight"><div class="insight-label"><span>${icons[category] || '✦'} ${category}</span><span>${currency.format(amount)}</span></div><div class="insight-bar"><span style="width:${(amount / largest) * 100}%"></span></div></div>`).join('');
}

form.addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(form);
  expenses.push({
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    name: data.get('name').trim(),
    amount: Number(data.get('amount')),
    category: data.get('category'),
    date: data.get('date')
  });
  saveExpenses();
  form.reset();
  dateInput.value = localToday();
  render();
});

filter.addEventListener('change', render);
search.addEventListener('input', render);

document.querySelector('#editBudgetButton').addEventListener('click', () => {
  budgetInput.value = monthlyBudget || '';
  budgetDialog.showModal();
  budgetInput.focus();
});
document.querySelector('.dialog-close').addEventListener('click', () => budgetDialog.close());
document.querySelector('#budgetForm').addEventListener('submit', event => {
  event.preventDefault();
  monthlyBudget = Number(budgetInput.value);
  writeStore('pocketwise-budget', String(monthlyBudget));
  budgetDialog.close();
  render();
});
document.querySelector('#removeBudgetButton').addEventListener('click', () => {
  monthlyBudget = 0;
  try { localStorage.removeItem('pocketwise-budget'); } catch (e) {}
  budgetDialog.close();
  render();
});
document.querySelector('#clearButton').addEventListener('click', () => {
  if (expenses.length && confirm('Delete all saved expenses? This cannot be undone.')) {
    expenses = [];
    saveExpenses();
    render();
  }
});
function updateScopeButtons() {
  document.querySelectorAll('.scope-option').forEach(button => {
    const active = button.dataset.scope === insightScope;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', active ? 'true' : 'false');
  });
}
document.querySelectorAll('.scope-option').forEach(button => {
  button.addEventListener('click', () => {
    insightScope = button.dataset.scope;
    writeStore('pocketwise-scope', insightScope);
    updateScopeButtons();
    renderInsights();
  });
});
updateScopeButtons();

document.querySelector('#exportButton').addEventListener('click', () => {
  if (!expenses.length) return;
  const lines = ['Name,Amount,Category,Date', ...expenses.map(expense => [expense.name, expense.amount, expense.category, expense.date].map(value => `"${String(value).replaceAll('"', '""')}"`).join(','))];
  const link = document.createElement('a');
  link.href = URL.createObjectURL(new Blob([lines.join('\n')], { type: 'text/csv' }));
  link.download = 'pocketwise-expenses.csv';
  link.click();
  URL.revokeObjectURL(link.href);
});
render();
